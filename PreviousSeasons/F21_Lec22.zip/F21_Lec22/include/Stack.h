#ifndef STACK_H
#define STACK_H

#include"../listtoolshb.h" //path
#include<iostream>
template<class T>
class Stack
{
    public:
        Stack():top(NULL){}
        void push(T element);
        bool isEmpty();

    private:
        Node<T> *top; //introducing a pointer which is a type of Node class
};

#endif // STACK_H
