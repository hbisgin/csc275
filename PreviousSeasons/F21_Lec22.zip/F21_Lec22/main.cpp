#include <iostream>
#include "listtoolshb.h"
#include "listtoolshb.cpp"
#include "./include/Stack.h"
#include "src/Stack.cpp"


using namespace std;

int main()
{
    Node<string> * head = new Node<string>("Adam", NULL);
    string names[4]={"Sue", "Dan", "Dave", "Mary"};

    Stack<string> sStack; //I have no elements inside. That means the top pointer nothin but a NULL pointer
    string trial= "Adam";
    sStack.push(trial);

    for(int i=0; i<4; i++)
    {
        headInsert(head, names[i]);
         sStack.push(names[i]);
    }



    display(head);
//template<class T> Node<T>* search(Node<T>* head, const T& target);
//template<class T>  void deleteNode(Node<T>* before);
    string target = "Dave";
    Node<string> * before = search(head, target );
    deleteNode(before);
    cout<<"after deleting Dan:"<<endl;
    display(head);
    return 0;
}
