#include "../include/Stack.h"

template<class T>
void Stack<T>::push(T element)
{
    //head = new Node<T>(theData, head);
    top  = new Node<T>(element, top);
}

template<class T>
bool Stack<T>::isEmpty()
{
    return top==NULL;
}
