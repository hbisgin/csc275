#include<iostream>
#include<string>

using namespace std;

struct Date{
    int month, day, year;
};

struct Dept{
    string DName;
    int dID;
};

struct Employee{
    string name;
    string lastname;
    Date DOB;
    Date StartDate;
    Dept eDepartmentInfo;
};

enum Day {Mon=100, Tue=3, Wed=-3, Thu=0, Fri=0, Sat=7, Sun};

int main()
{
    Employee e1;
    Day dd=Mon;//neither string nor integer, be careful
    //Day dd = 3; //you can't do this!
    e1.name="Halil";
    e1.StartDate.month=9;
    e1.StartDate={9, 8, 2010};//alternative initilization
    e1.StartDate.day=8;
    e1.StartDate.year=2010; //it's like chain. you have to keep using dots
    cout<<e1.StartDate.year<<endl;

    cout<<dd<<endl;


    switch(dd){
        case Mon:
            cout<<"its monday"<<endl;
            break;
        case Wed:
            cout<<"it's wednesday"<<endl;
            break;

    };

}
