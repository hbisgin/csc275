#include<iostream>
#include<string>
#include<vector>
using namespace std;


struct CarType{
    string make;
    string model;
    int price;
    int year;
    bool operator==(CarType car2){return price==car2.price;}//member operator
};

class Fruit{
    public:
        Fruit():price(0){count++;}
        Fruit(int pprice):price(pprice){count++;}
        int getCount(){return count;}
        int getPrice(){return price;}
        void setPrice(int pprice){price=pprice;}
        //const int operator +(Fruit f2){return price+f2.getPrice();}
        const Fruit operator +(Fruit f2){return Fruit(price + f2.getPrice());}
    private:
        static int count; //all instances of Fruit will know about count
        int price;
};
//non-member overloaded operator
bool operator>(CarType car1, CarType car2){return car1.price>car2.price;}
bool operator>(Fruit f1, Fruit f2){return f1.getPrice()>f2.getPrice();}
int Fruit::count=0;

int main(){

    CarType c1={"Honda", "Civic", 3500, 2010}, c2={"Honda", "Accord", 4500, 2012};
    Fruit fruit1(10), fruit2(2), fruit3;
    if (c1>c2)
    {
        cout<<"first car is more expensive"<<endl;
    }else{
        cout<<"first car is less expensive"<<endl;
    }

    if(c1==c2)
    {
        cout<<"prices are the same"<<endl;
    }else{
        cout<<"prices are NOT the same"<<endl;
    }

    if (fruit1>fruit2)
    {
        cout<<"first fruit is more expensive"<<endl;
    }else{
        cout<<"first fruit is less expensive"<<endl;
    }

    //cout<<"total cost is "<<(fruit1+fruit2)<<endl;
    fruit3 = fruit1+fruit2;
    //(fruit1+fruit2).setPrice(15);
    cout<<fruit3.getPrice()<<endl;

}
