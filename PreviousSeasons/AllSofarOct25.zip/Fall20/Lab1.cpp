#include<iostream>

using namespace std;

struct Srecord{
    float quiz1, quiz2, exam1, exam2, average;
    char letter;
};

void fungrade(Srecord &s); //pass by reference

int main()
{
    Srecord s1 = {9, 8, 79, 89}; //declare + initialize
    fungrade( s1); //do I need & here when I call?
    cout<<s1.average<<endl;

    cout<<s1.letter<<endl;

}

void fungrade(Srecord &s)
{
    s.average = (s.quiz1 + s.quiz2)*.5*10*0.25 + s.exam1*0.25 + s.exam2*0.5;

    if(s.average>=90)
        s.letter='A';
    else if (s.average>=80)
        s.letter='B';
    else if (s.average>=70)
        s.letter='C';

    //if there's invalid score, you can call it N

}
