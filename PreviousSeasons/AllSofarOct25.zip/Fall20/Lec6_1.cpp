#include<iostream>
#include<string>

using namespace std;

class Point{
public:
    Point(){x=0; y=0; numOfPoints++;} //this is also an inline function, meaning definition is given here
    Point(int a, int b);
    int getX()const { return x; } //inline function because I put the def'n here
    int getY(){return y; } //inline function because I put the def'n here
    int getNumofPoint(){return numOfPoints;}
private:
    int x, y;
    static int numOfPoints;

};

class Line{

public:
    Line(Point pt1, Point pt2);//this also took Point objects as parameter
    Point getPoint1(){ return p1;} //inline function because I put the def'n here
    Point getPoint2(){ return p2;} //inline function because I put the def'n here
private:
    Point p1, p2;

};

inline void display(Point &pt);//pass by reference
//this is not a member function

void counter(){
    static int mycount=0;
    mycount++;
    cout<<mycount<<endl;
}

int Point::numOfPoints=0;

int main(){

    Point point1(2,5), point2(1, 4);
    Line line(point1, point2);
   //cout<<point1.getX()<<endl;
   cout<<line.getPoint1().getX()<<endl;
   cout<<line.getPoint2().getX()<<endl;
   display(point1);

   cout<<point1.getNumofPoint()<<endl;

   for(int i=0;i<5; i++)
          counter();


}

void display(Point &pt)
{
    cout<<pt.getX()<< ","<<pt.getY()<<endl;
}
Point::Point(int a, int b):x(a), y(b){
//x = a;
//y = b;
numOfPoints++;
}

/*Point::Point()
{
    x=0;
    y=0;
}
*/

Line::Line(Point pt1, Point pt2){
    p1 = pt1;
    p2 = pt2;
}
