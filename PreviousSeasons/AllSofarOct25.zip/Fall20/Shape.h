
class Shape{

public:
    Shape();
    Shape(float side);
    void setSide(float s);
    float getArea();
protected:
    float side1;

};
