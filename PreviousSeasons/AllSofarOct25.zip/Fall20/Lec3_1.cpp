#include<iostream>
#include<string>

using namespace std;

class Employee{
    public:
        string Name;
        string LastName;
        int eID;
        void output();
};

//unless you put public identifier, everything will be private in a class
//on the other hand, in a struct, unless you put private, everything will be public

int main()
{
    Employee e1; //e1 is an instance of Employee class
    e1.Name="john";
    e1.LastName="doe";
    e1.eID=123;

    cout<<e1.Name<<" "<<e1.LastName<<endl;//since data members are public
    //I csn access by using dot operator
    e1.output(); //I call a public function to display my data members
}

void Employee::output()
{
    cout<<Name<<" "<<LastName<<" "<<eID<<endl
    //your member functions will know about your data members
}
