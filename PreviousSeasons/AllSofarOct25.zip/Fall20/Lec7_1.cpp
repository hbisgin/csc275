#include<iostream>
#include<string>
#include<vector>
using namespace std;


void counter()
{
    static int count=0;
    count++;
    cout<<count<<endl;
}

void counter2()
{
    int count=0;
    count++;
    cout<<count<<endl;
}


class Fruit{
    public:
        Fruit():price(0){count++;}
        Fruit(int pprice):price(pprice){count++;}
        int getCount(){return count;}
        static bool stillAvailable();
    private:
        static int count; //all instances of Fruit will know about count
        static int totalaval;
        int price;
};

int Fruit::count=0;
int Fruit::totalaval=5;
int main(){

    Fruit f1, f2(10);
    vector<int> v1; //default constructor wil ltake of initializations.
    v1.push_back(240);
    cout<<v1.size()<<endl;
    cout<<f1.getCount()<<endl;
    cout<<f2.getCount()<<endl;

    for(int i=0; i<10; i++)
        counter();

    for(int i=0; i<10; i++)
        counter2();

    //cout<<count<<endl;

}
