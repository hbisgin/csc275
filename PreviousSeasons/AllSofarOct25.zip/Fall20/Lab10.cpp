#include<iostream>
#include<cmath>
#include<string>

using namespace std;

#define N 5
//I was having some trouble implementing N

class Point{
    public:
        Point():x(0),y(0),z(54){}
        Point(int a):x(a),y(0),z(54){}
        Point(int a, int b):x(a),y(b),z(54){}
        int getX(){return x;}
        int getY(){return y;}
        int z;
    private:
        int x;
        int y;

};

Point * fillPointArray(Point parray[]);
Point * fillPointArray2(Point *ptr);

int main()
{
    typedef int* IntPtr;
    IntPtr ptr1;
    //Point *ptr2 = new Point(5,1);
    cout<<ptr1<<endl;
    *ptr1 = 10;
    if (ptr1 != NULL)
    {
        cout<<*ptr1<<endl;
    }
    //cout<<ptr2->getX()<<","<<ptr2->getY()<<","<<ptr2->z<<endl;


  /*  Point parray[N];
    Point *ptr3 = fillPointArray(parray); //array names already have the address, no need for &
    for(int i=0; i<N; i++)
    {
        cout<<ptr3[i].getX()<<" "<<ptr3[i].getY()<<endl;
    }
*/


}


Point * fillPointArray(Point parray[])
{
    for(int i = 0; i<N; i++)
    {
       parray[i] = Point(i, pow(i,2));
    }
    return parray;
}

Point * fillPointArray2(Point *parray)
{

    return parray;
}
