#include<iostream>
#include<string>

using namespace std;

//forward declaration
//class Point;



class Point{
public:
    Point():x(0),y(0){}
    Point(int xx, int yy):x(xx), y(yy){}
    friend void changePoint(Point &p1, int xx, int yy);
    friend class Fruit;
    int getX(){return x;}
    int getY(){return y;}
private:
    int x,y;
};

class Fruit{
public:
    void resetPoints(Point &p1);
private:
};


int main(){

    Point p1(3,4);
    cout<<p1.getX()<<" "<<p1.getY()<<endl;
    changePoint(p1, 10, 20);
    cout<<p1.getX()<<" "<<p1.getY()<<endl;
    Fruit fruit1;
    fruit1.resetPoints(p1);
    cout<<p1.getX()<<" "<<p1.getY()<<endl;

    int number = 10; //regular integer variable declaration
    int &no = number; //no is a reference variable which needs to be initialized during declarion
    cout<<number<<endl;
    no = 15;
    cout<<number<<" "<<no<<endl;
}

void changePoint(Point &p1, int xx, int yy) //non-member
{
    p1.x = xx; //we don't need the get fuction to access x component
    p1.y = yy; //save the function call for the get function
    //these x and y's are "public" (visible) for you
}

void Fruit::resetPoints(Point &p1)
{
    p1.x=0;
    p1.y=0;
}
