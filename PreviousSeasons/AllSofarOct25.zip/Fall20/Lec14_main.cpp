#include<iostream>
#include "Shape.h" //header file
using namespace std;

int main()
{
    Shape s1, s2(4);
    s1.getArea();
    s2.getArea();
}
