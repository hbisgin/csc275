#include<iostream>
#include<string>

using namespace std;

//creating someting which imitates vector class in C++
//dynamic array, but we need to create it in a different way
//not just [ ]
//void myfun(Array aobj);// will  call your copy constructor

class Array{
    public:
        Array(int size=2){a = new int[size]; capacity=size; used=0;}
        Array(const Array &obj);
        ~Array();
        int & operator[](int index){return a[index];}//since a is apointer
        //i can use them like an array name and get the location, *(a+index)
        Array& operator=(const Array &rhs);
        void addElement(int element);
        int getCapacity(){return capacity;}
        int getUsed(){return used;}
    private:
        int capacity;//
        int used;
        int *a;//this is a pointer, we need to be careful

};

int main(){
    Array aobj, bobj(5); //two Array objects, aobj has size of 2
    aobj.addElement(5);
    aobj[0] = 50; //[] on the left, helps me assign a value
    aobj.addElement(100);
    cout<<aobj[0]<<endl;//[] is on the RHS, helps me retrieve the value
    cout<<aobj[1]<<endl;
    bobj = aobj;
    cout<<aobj.getCapacity()<<" and used: "<<aobj.getUsed()<<endl;
    cout<<bobj.getCapacity()<<" and used: "<<bobj.getUsed()<<endl;
}

void Array::addElement(int element)
{
    a[used] = element;
    used++;
}

Array::~Array() //free the memory and destroy the object
{
    delete [] a;
}

Array::Array(const Array &obj)//copy constructor
{
    capacity = obj.capacity;
    used = obj.used;
    a = new int[capacity];//a now hold a different address space
    for(int i=0; i<used; i++)
        a[i] = obj.a[i];

       // return Array();
}

Array & Array::operator=(const Array &rhs)
{
    if(this == &rhs)
        return *this;

    delete [] a;// how you delete a memory location which is in array shape
                    //delete x where x is a pointer and holding address of a single variable
    capacity = rhs.capacity;
    used = rhs.used;
    a = new int[capacity];//a now hold a different address space
    for(int i=0; i<used; i++)
        a[i] = rhs.a[i];

    return *this; //this pointer will refer to object itself.
    //by using * you're returning a location, you kept your promise;
}
