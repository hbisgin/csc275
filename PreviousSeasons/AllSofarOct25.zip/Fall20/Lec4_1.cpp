#include<iostream>
#include<string>

using namespace std;

class Fruit{
    public:
        Fruit();
        void setName(string fname);
        string getName();
        void setID(int pid);
        int getID();
        void setWeight(float pweight);
        void setPrice(float pprice);
        float getTotalCost();
    private:
        string name;
        int pID;
        float price;
        float weight;
        float total_cost;
};

int main()
{
    //Fruit fruit1.name="Banana"; //it's private
    Fruit fruit1; //create an object
    fruit1.setName("Banana");//set the name to Banana;
    //cout<<fruit1.name<<endl; //private, can't use dot operator
    cout<<fruit1.getName()<<endl;
    fruit1.setID(4011);
    fruit1.setPrice(0.57);
    fruit1.setWeight(2);
    cout<<fruit1.getID()<<endl;
    cout<<fruit1.getTotalCost()<<endl;
}

void Fruit::setName(string fname)
{
    name = fname;
}

string Fruit::getName()
{
    return name;
}

void Fruit::setID(int pid)
{
    pID = pid;
}

int Fruit::getID()
{
    return pID;
}

void Fruit::setWeight(float pweight){
    weight = pweight;
}

void Fruit::setPrice(float pprice)
{
    price = pprice;
}

float Fruit::getTotalCost(){
    total_cost = weight * price; //member function can see your data members as welll
    //you don't have to call your getter (accessor) function.
    return total_cost;
}

Fruit::Fruit(string fname)
{
    name = fname;
}

