#include<iostream>
#include<string>

using namespace std;

int main(){
    int a=5, b=10; //declaration + initialization
    int *ptr; //declaration
    int *ptr2 = &a;//declaration + initialization, it's with star
    ptr = &a; //pointer initialization, assignment, here not star
    //*ptr2 = &b, incorrect, attempting to assing an address to a location which can hold int
    cout<<a<<endl;
    cout<<*ptr<<endl;

    ptr2 = &b;

    *ptr=100;//on the LHS, you can assign values;

    a= *ptr2; //on the RHS, you pull the value;
    ptr = ptr2;
    cout<<a<<endl;
    cout<<ptr2<<endl;

    int *ptr3 = new int; //new operator will grab an address from the memory

}
