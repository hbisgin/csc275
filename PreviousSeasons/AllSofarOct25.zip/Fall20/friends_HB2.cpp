#include <iostream> 

using namespace std;


class NFL{
    public:
        NFL():jNumber(0),salary(0){}
        NFL(int number, int ss):jNumber(number), salary(ss){}
        friend class NBA;
        int getSalary(){return salary;}
    private:
        int salary;
        int jNumber;
    


};

class NBA{
    public:
        NBA():jNumber(0),salary(0){}
        NBA(int number, int ss):jNumber(number), salary(ss){}
        int getSalary(){return salary;}
        void setSalary(int ss){salary = ss;}
        void make_same(NFL &NFLplayer){ if (jNumber == NFLplayer.jNumber) {salary = NFLplayer.salary;}}
        friend void setSalary(NBA &f, int b){f.salary = b;}
    private:
        int salary;
        int jNumber;
        

};




int main()
{
    NBA NBAplayer(9,100);
    NFL NFLplayer(9, 120);
    
    setSalary(NBAplayer,20);
    cout<<NFLplayer.getSalary()<<endl;
    cout<<NBAplayer.getSalary()<<endl;
    NBAplayer.make_same(NFLplayer);
    cout<<NBAplayer.getSalary()<<endl;
    cout<<NFLplayer.getSalary()<<endl;
}


