#include<iostream>
#include<string>

using namespace std;

class Profile{
    public:
        Profile():name("Jane"), lastname("Doe"), age(18){}
        string getName(){return name;}
        string getLastName(){return lastname;}
        int getAge(){return age;}
    private:
        string name, lastname;
        int age;
};

class Twitter{
   public:
       Twitter(Profile person):TwProfile(person), NumFollowers(0){}

   private:
        Profile TwProfile;
        int NumFollowers;
};



int main(){
    Profile persona1;
    Twitter Account1(persona1);

    Account1.ChangeProfile("Halil");
    Account1.ChangeProfile("Halil", "Bisgin");
    Account1.ChangeProfile("Halil", "Bisgin", 40);




}


