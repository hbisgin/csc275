#include"Shape.h"
#include<iostream>

using namespace std;

    Shape::Shape(){side1=1;}
    Shape::Shape(float side){side1=side;}
    void Shape::setSide(float s){side1=s;}
    float Shape::getArea(){cout<<"don't call me!"<<endl; return 0;}
