
class Square:public Shape{
    public:
    float getArea();

};
