#include<iostream>
#include<string>

using namespace std;

class Vector{
public:
    Vector():x(0), y(0){}
    Vector(int xx, int yy):x(xx), y(yy){}
    void setX(int xx){x=xx;}
    void setY(int yy){y=yy;}
    int getX()const {return x;}
    int getY()const {return y;}
    void display() const;
    const Vector operator + (const Vector &v2) const;
private:
    int x,y;

};


const Vector operator - (const Vector &v1, const Vector &v2);
const Vector operator - (const Vector &v1);

int main(){
    Vector v1(3,4), v2(0,5);
    Vector v3 = v1+v2;
    v3.display();
    Vector v4 = v1-v2;
    v4.display();
    Vector v5 = -v4;
    v5.display();
}

const Vector Vector::operator + ( const Vector &v2) const
{
    int xlocal, ylocal;
    xlocal = x + v2.getX();
    ylocal = y + v2.getY();
    return Vector(xlocal, ylocal);
}

const Vector operator - (const Vector &v1, const Vector &v2)
{
    int xlocal, ylocal;
    xlocal = v1.getX() - v2.getX();
    ylocal = v1.getY() - v2.getY();
    return Vector(xlocal, ylocal);
}

const Vector operator - (const Vector &v1)
{
    return Vector(-v1.getX(), -v1.getY());
}

void Vector::display() const {
    cout<<x<<" " <<y<<endl;

}
