#include<iostream>
#include<string>
#include<cstdlib>

using namespace std;

int main(){
    int *ptr;
    int *ptr2 = new int; //this will open up space for an integeer
    int *ptr3 = new int[10]; //this will open up space for 10 integers (consecutive)
    ptr3[0]=12;
    ptr3[1] = 100;
    cout<<ptr3[1]<<endl;

    int **a = new int*[3];//what does it mean?

    for(int i=0; i<3; i++)
        a[i] = new int[4];

    for(int i=0; i<3; i++)
        for(int j=0; j<4; j++)
            a[i][j] = rand()%10;

     for(int i=0; i<3; i++)
        for(int j=0; j<4; j++)
                    cout<<a[i][j]<<endl;



}
