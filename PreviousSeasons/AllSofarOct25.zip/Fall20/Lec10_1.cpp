#include<iostream>
#include<string>

using namespace std;

//myfun(int a); //pass by value; it will make a local copy inside the fun
//myfun(int &a); //pass by reference; it will take you to the address, no local copy
//myfun(int *a); //pass by pointer; it will let you pointer see the address of your parameter

class Fruit{
public:
    Fruit(){}
    Fruit(string fname, float fprice):name(fname), price(fprice){}
    float weight; //for a public data member, I don't need getter or setter
    string getName(){return name;}
    float getPrice(){return price;}
private:
    string name; //I need getters and setters as needed
    float price;

};

void doublemyvalue(int *ptr); //pass by pointer

int main(){
    int a=5, b=10, c=100;
    Fruit *fptr; //declared a Fruit pointer
    fptr  = new Fruit("Grapes", 2.99); //reserve a memory location to store a Fruit object
    //Fruit f(....), f.weight=2
    (*fptr).weight=2;
    fptr->weight=2;
    cout<<fptr->weight<<endl;
    cout<<fptr->getName()<<" "<<fptr->getPrice()<<endl;
    cout<<(*fptr).getName()<<" "<<(*fptr).getPrice()<<endl;

    delete fptr;
    fptr = NULL;

    int &r = a; // r is a reference variable, you can't link it to another variable (address)
    int *ptr = &b; //ptr is a pointer =, you can link it to other address
    //unless you put a constraint like const. Not really loyal.
    //for both r and ptr, having them on the RHS will give you their current values and having them
    //on the LHS will let you write values.
    ptr = &c; //assigning an address, not  ASTERISK please becauuse it's a RISK
    cout<<c<<endl;
    doublemyvalue(&c);
    cout<<c<<endl;
    int *ptr2 = new int; //declaration and initialization at the same time
   cout<<ptr<<endl;
    ptr = new int;
    *ptr2 = 500;
    cout<<*ptr2<<endl;
    cout<<ptr2<<endl;
    cout<<ptr<<endl;

}

void doublemyvalue(int *ptr)
{
     *ptr = *ptr * 2; //*ptr on the RHS retrieved the value, *ptr on the LHS helped me update the  value, I assigned a new value
}
