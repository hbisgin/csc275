#include<iostream>
#include<string>

using namespace std;

class Fruit{
    public:
        Fruit(); //default constructor
        Fruit(string fname);
        Fruit(string fname, float fweight);
        string getName();
        float getWeight();
        float getPrice();
    private:
        float weight;
        float price;
        string name;

};

int main()
{
    Fruit fruit1, fruit2("Banana"), fruit3("Grapes", 2.3); //We declared an object and initialized by the help of my constructor
    Fruit fruit4 = Fruit();
    //IF you're creating an object with a constructor with no parameters, don't use parantheses
    //If you're creating an object and assigning it to a object you create by using a constructor
    //with no parameter, please use ()

    cout<<fruit1.getName()<<endl;
    cout<<fruit1.getWeight()<<endl;
    cout<<fruit1.getPrice()<<endl;

    cout<<fruit2.getName()<<endl;
    cout<<fruit2.getWeight()<<endl;
    cout<<fruit2.getPrice()<<endl;

    cout<<fruit3.getName()<<endl;
    cout<<fruit3.getWeight()<<endl;
    cout<<fruit3.getPrice()<<endl;

    cout<<fruit4.getName()<<endl;
    cout<<fruit4.getWeight()<<endl;
    cout<<fruit4.getPrice()<<endl;

}

Fruit::Fruit(){
    name = "Orange";
    weight=0;
    price = 3.99;
}

Fruit::Fruit(string fname)
{
    name = fname;
    weight=0;
    price = 3.99;
}

/*Fruit::Fruit(string fname, float fweight)
{
    name = fname;
    weight = fweight;
    price = 3.99;
}*/

//initialization list or section
Fruit::Fruit(string fname, float fweight):name(fname), weight(fweight)
{
    price = 3.99;
}

string Fruit::getName(){
    return name;
}

float Fruit::getWeight(){
    return weight;
}

float Fruit::getPrice(){
    return price;
}

