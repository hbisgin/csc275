#include<iostream>
#include<string>

using namespace std;

class ATM{
    public:
        float balance;
        void showBalance();
        void deposit(float amount);
        bool withdraw(float amount);
};

int main()
{
    ATM atm_obj;
    atm_obj.balance=250;
    atm_obj.showBalance();
    atm_obj.deposit(250);
    atm_obj.showBalance();
    cout<<atm_obj.withdraw(100)<<endl;
    atm_obj.showBalance();


}

void ATM::showBalance()
{
    cout<<balance<<endl;
}

void ATM::deposit(float amount)
{
    balance+=amount;
}

bool ATM::withdraw(float amount)
{
    if (balance>=amount)
    {
        balance-=amount;
        return true;
    }else{

        return false;
    }

}
