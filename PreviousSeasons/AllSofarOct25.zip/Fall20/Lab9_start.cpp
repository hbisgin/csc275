#include<iostream>
#include<string>
#include<cstdlib>

using namespace std;

#define N 5

class Profile{
    public:
        Profile(){}
        Profile(string fname, string plastname, int page):name(fname),lastname(plastname),age(page){}
        Profile(int sage){age=sage;}
        void setAge(int pp){age=pp;}
        int getAge(){return age;}
        void setName(string nn){name=nn;}
        string getName(){return name;}
        //define your operator > here
        bool operator>(Profile &p2); //member function
        int & operator[](int index);
        void displayArray();
        friend ostream & operator<<(ostream &var, Profile p);

    private:
        string name, lastname;
        int id, age;
        int a[N];


};


int main()
{
    //Define two Profile objects, p1 and p2 in a way that p1 is older than p2
    //so that display function can work.
    Profile p1("John", "Doe", 18), p2("Jane", "Doe", 17);
    cout<<(p1>p2)<<endl;

//    uncomment below when you are done with the ostream function
//    cout<<"Array members for"<<p1<<" are: "<<endl;

    for(int i=0;i<N;i++)
        p1[i]=1 + rand()%6; //p1 is an object and Im able to fill its array members with the help of [ ]

    cout<<"here is "<<p1<<" array values:"<<endl;
    if(p1>p2) //uncomment this part when your operator is ready
        p1.displayArray();
}

//define your member operator > here
bool Profile::operator>(Profile &p2)
{
    return age>p2.getAge();
}

int & Profile::operator[](int index)
{
    return a[index];

}


ostream & operator<<(ostream &var, Profile p)
{
    var<<p.name<<" "<<p.lastname<<" "<<p.age;
    return var;

}

//define your member display function here
void Profile::displayArray()
{
    for(int i=0;i<N;i++)
        cout<<a[i]<<endl;
}
