#include<iostream>
#include<string>

using namespace std;

struct Fruit{
    string name; //c++ style string declaration
    float weight;
    float unitprice;
    float total;
};

Fruit CalculateTotalCost(Fruit F);

int main()
{
    Fruit fruit1, fruit2, fruit3, fruit4;
    Fruit fruits[4];
    fruits[3].name="Fig";
    fruits[2].name="Grapes";

    for(int i=0; i<4; i++)
        cout<<fruits[i].name<<endl;

    fruit1.name="Apple";
    fruit1.weight=3;
    fruit2.name="Orange";
    fruit3.name="Orange";

    fruit2 = fruit1; //neither fruit1 nor fruit2 is string, they are both Fruit datatype
    cout<<fruit2.name<<endl;
    cout<<fruit1.name<<endl;

    fruit1.unitprice=2;
    fruit3.unitprice=2;

    //we can assign struct objects to each other, but we can't compare them without
    //overloaded operators
    //if(fruit1 == fruit3)
      //  cout<<"they're the same"<<endl;

    if(fruit1.unitprice==fruit3.unitprice)
        cout<<"they cost the same"<<endl;

    fruit4=CalculateTotalCost(fruit1); //passing by value

    cout<<fruit4.name<<endl;
    cout<<fruit4.weight<<endl;
    cout<<fruit4.total<<endl;
    cout<<fruit1.total<<endl;


}

Fruit CalculateTotalCost(Fruit F)
{
    F.total= F.unitprice*F.weight;
    return F;
}
