#include<iostream>
#include<string>

using namespace std; //directive

//using std::cout;
//using std::endl; //declaration


namespace oct15{

void fun(){cout<<"hello from the namespace"<<endl;}
}

int main(){

using namespace oct15;
fun();
//oct15::fun();
//std::cout<<"hello"<<std::endl;

//std::cout<<"second"<<std::endl;
}
