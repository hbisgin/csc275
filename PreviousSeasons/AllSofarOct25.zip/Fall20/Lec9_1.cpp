#include<iostream>
#include<string>

using namespace std;

//member function definition should use ::
//friend function has access, but not a member. You should still define this guy

//overloaded operators:
//member function, but its first parameter is the class object itself
//friend function, it will have access without get functions to your object
//other, outside the class definition,
//but this involve the class object as a parameter as well

//reference variables
double & myfun(double &a);
//void myfun(double &a, double b){a=b;}

class Fruit{
    public:
        Fruit():name("Banana"), price(1){}
        friend ostream& operator<<(ostream &output, Fruit &f);
        string& operator[](int index){if(index==1) return name;}
    private:
        string name;
        int price;

};

ostream& operator<<(ostream &output, Fruit &f)
{
  output<<f.name<<" "<<f.price;
  return output;
}

int main(){
    Fruit fruit1;
    //fruit1++; //overloaded function needed, you decide what members are going to be affected.
    cout<<fruit1<<endl;
    cout<<fruit1[1]<<endl;
    fruit1[1] = "Grape"; //fruit1.setName("Grape")
    cout<<fruit1[1]<<endl;

    int a=5;
    cout<<++a<<endl; //a++ unary operator
    cout<<a<<endl;

    int &r = a; //reference variables are not pointers
    double b = 60, c;
    cout<<a<<endl;//<<(cout, a)
    r = 10;
    cout<<a<<endl;
    cout<<r<<endl;

    cout<<b<<endl;
    myfun(b)=85;
    cout<<b<<endl;
    cout<<myfun(b)<<endl;
    c=myfun(b); //c = b, (5=a; incorrect, a=5; correct)
    cout<<c<<endl;

    Fruit f;
    //cout<<f<<endl; //you need an overloaded for <<
    //cin>>f; //you need overloaded operator >>
}

double & myfun(double &a)
{
    return a;
}
