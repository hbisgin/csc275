#ifndef GRAD_H
#define GRAD_H


class Grad
{
    public:
        Grad();
        virtual ~Grad();

    protected:

    private:
};

#endif // GRAD_H
