#include <iostream>
#include"Student.h"
#include"UGrad.h"
//#include"Grad.h"

using namespace std;

int main()
{
    Student s1;
    UGrad us1;
    //Grad grs1;
    cout << "Hello world!" << endl;
    s1.display();
    us1.display();
    return 0;
}
