#include "Grad.h"

Grad::Grad()
{
    //ctor
}

Grad::~Grad()
{
    //dtor
}
